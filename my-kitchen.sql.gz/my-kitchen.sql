-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2022 at 08:00 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my-kitchen`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `full_name`, `username`, `password`) VALUES
(20, 'Tamanna Akther', 'tamanna', '827ccb0eea8a706c4c34a16891f84e7b'),
(21, 'anika Tabassum', 'Anika', '827ccb0eea8a706c4c34a16891f84e7b'),
(24, 'Tamanna', 'Tam', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `title`, `image_name`, `featured`, `active`) VALUES
(20, 'Coffe', 'Food_Category_907.jpg', 'Yes', 'Yes'),
(21, 'Cup Cake', 'Food_Category_553.jpg', 'Yes', 'Yes'),
(22, 'Stack', 'Food_Category_46.jpg', 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_food`
--

CREATE TABLE `tbl_food` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_food`
--

INSERT INTO `tbl_food` (`id`, `title`, `description`, `price`, `image_name`, `category_id`, `featured`, `active`) VALUES
(27, 'Cake', 'Sweet taste', '100', 'Food-Name-9318.jpg', 21, 'Yes', 'Yes'),
(28, 'Sweets', 'Sweets', '100', 'Food-Name-8501.jpg', 22, 'Yes', 'Yes'),
(29, 'Pizza', 'Pizza', '100', 'Food-Name-781.jpg', 22, 'Yes', 'Yes'),
(30, 'Omelate', 'Sweets Omelate ', '120', 'Food-Name-7877.jpg', 22, 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(10) UNSIGNED NOT NULL,
  `food` varchar(150) NOT NULL,
  `price` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` decimal(10,0) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(10) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_contact` varchar(20) NOT NULL,
  `customer_email` varchar(150) NOT NULL,
  `customer_adress` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `food`, `price`, `qty`, `total`, `order_date`, `status`, `customer_name`, `customer_contact`, `customer_email`, `customer_adress`) VALUES
(2, 'burger', '12', 2, '24', '2022-07-22 12:59:53', 'Ordered', 'Kaseem Shaffer', '+1 (298) 451-4687', 'kibebo@mailinator.com', ''),
(3, 'burger', '12', 7, '84', '2022-07-22 01:02:47', 'Ordered', 'Brock Clayton', '+1 (723) 776-3423', 'jibyvatej@mailinator.com', ''),
(4, 'burger', '12', 7, '84', '2022-07-22 01:09:08', 'Ordered', 'Reuben Richardson', '+1 (576) 208-5733', 'dyjulypo@mailinator.com', ''),
(5, 'burger', '12', 1, '12', '2022-07-22 01:16:14', 'Ordered', 'Athena Mcclain', '+1 (169) 318-6817', 'dyjiqijuku@mailinator.com', ''),
(6, 'burger', '12', 9, '108', '2022-07-22 01:17:05', 'Ordered', 'Amal Mays', '+1 (547) 896-1759', 'kete@mailinator.com', ''),
(7, 'burger', '100', 4, '400', '2022-07-23 05:19:32', 'Ordered', 'Colleen Delacruz', '+1 (769) 456-9751', 'merahop@mailinator.com', ''),
(8, 'burger', '100', 4, '400', '2022-07-23 08:38:45', 'Ordered', 'Basil Randall', '+1 (179) 114-5287', 'habagagu@mailinator.com', ''),
(9, 'burger', '100', 905, '90500', '2022-07-24 08:01:16', 'Ordered', 'Imani Herman', '+1 (746) 933-5842', 'zupypuhej@mailinator.com', 'Omnis quisquam fugia'),
(10, 'burger', '100', 7, '700', '2022-07-24 03:17:13', 'Ordered', 'Caryn Kinney', '+1 (802) 389-8064', 'conavonico@mailinator.com', 'Sapiente architecto '),
(11, 'burger', '150', 1, '150', '2022-07-24 03:48:55', 'Ordered', 'tamanna', '017131245123r1', 'tamannatahmi365@gmail.com', 'sylhet'),
(12, 'pizza', '800', 1, '800', '2022-07-24 04:06:45', 'Ordered', 'tamanna', '01666343616', 'tamannatahmi365@gmail.com', 'sylhet,mirabajar'),
(13, 'burger', '150', 2, '300', '2022-07-24 04:21:54', 'Ordered', 'Anika', '01713124512', 'anika@gmail.com', 'Sylhet'),
(14, 'burger', '150', 4, '600', '2022-07-24 05:30:21', 'Ordered', 'Tamanna Akther Rima', '017131245123r1', 'tamannatahmi365@gmail.com', 'sylet'),
(15, 'momo', '180', 3, '540', '2022-07-24 08:48:05', 'Ordered', 'Tamanna Akther Rima', '017131245123r1', 'tamannatahmi365@gmail.com', 'sdfghaers'),
(16, 'burger', '150', 1, '150', '2022-07-25 11:42:18', 'Ordered', 'Tamanna Akther Rima', '017131245123r1', 'tamannatahmi365@gmail.com', 'Sylhet'),
(17, 'burger', '150', 1, '150', '2022-07-25 11:54:53', 'Ordered', 'Tamanna Akther Rima', '017131245123r1', 'tamannatahmi365@gmail.com', 'Sylhet'),
(18, 'momo', '180', 1, '180', '2022-07-25 12:33:48', 'Ordered', 'Tamanna Akther Rima', '017131245123r1', 'tamannatahmi365@gmail.com', 'sylhet'),
(20, 'Sweets', '100', 1, '100', '2022-07-26 02:52:03', 'Ordered', 'tamanna', '0171589934', 'tamannatahmi365@gmail.com', 'sylhet'),
(21, 'Cake', '100', 2, '200', '2022-07-26 06:56:34', 'Ordered', 'Tamanna Akther Rima', '017131245123r1', 'tamannatahmi365@gmail.com', 'sylhet');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_food`
--
ALTER TABLE `tbl_food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_food`
--
ALTER TABLE `tbl_food`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
